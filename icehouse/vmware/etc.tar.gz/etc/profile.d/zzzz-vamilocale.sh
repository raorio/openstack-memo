LANG=`/opt/vmware/bin/ovfenv --quiet --key vami.locale.\`/opt/vmware/bin/ovfenv --quiet --key vm.vmname\``
       if [ -z "$LANG" ];then
       LANG="C"
       fi
       export LANG 
